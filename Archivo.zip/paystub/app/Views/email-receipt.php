<!DOCTYPE html>
<html>
<head>
    <title>Your Paystubs</title>
</head>
<body>
    <p>Thank you for your purchase. Your paystubs are attached.</p>
</body>
</html>
