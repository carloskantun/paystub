<?php
namespace App\Controllers;

class TemplateController
{
    public function list()
    {
        // TODO: return available templates
    }
}
