<?php
namespace App\Services;

/**
 * AutoCalcService
 * Genera líneas básicas (earnings + taxes) a partir de inputs mínimos.
 * Mejora: incluye deducción estándar simple, Additional Medicare y configuración por ENV.
 * Simplificaciones / Limitaciones:
 *  - Un único ingreso "Regular Income" (usuario puede añadir más manualmente luego)
 *  - Federal: brackets 2024 (Single) + deducción estándar aproximada (sin créditos / withholding tables reales)
 *  - Social Security: 6.2% hasta wage base (no prorrateo fino de cruce en mitad de periodo)
 *  - Medicare: 1.45% + 0.9% adicional sobre exceso del umbral (Single) anualizado de forma lineal
 *  - State: tasa plana opcional (placeholder) – se puede sustituir por tablas progresivas futuras
 *  - No considera pre‑tax deductions ni allowances; resultado es estimación educativa
 */
class AutoCalcService
{
    private array $federalBrackets2024Single = [
        // threshold => rate
        0 => 0.10,
        11600 => 0.12,
        47150 => 0.22,
        100525 => 0.24,
        191950 => 0.32,
        243725 => 0.35,
        609350 => 0.37,
    ];
     // Defaults (override via env if disponible)
     private int $socialSecurityWageBase; // 2024 base
     private float $ssRate = 0.062;
     private float $medicareRate = 0.0145;
     private float $additionalMedicareRate = 0.009; // excess
     private float $additionalMedicareThresholdSingle = 200000.0; // Single filing
     private float $standardDeductionSingle = 14600.0; // 2024 approx

    private array $stateFlat = [
        'CA' => 0.01, // placeholder simple rates
        'NY' => 0.02,
        'TX' => 0.0,
        'FL' => 0.0,
        'IL' => 0.015,
    ];

    public function __construct()
    {
        // Permitir override por ENV sin romper si helper no existe
        $this->socialSecurityWageBase = (int)(function_exists('env') ? env('SS_WAGE_BASE', 168600) : 168600);
        if (function_exists('env')) {
            $sd = env('STANDARD_DEDUCTION_SINGLE'); if ($sd !== null) $this->standardDeductionSingle = (float)$sd;
            $amThr = env('ADDITIONAL_MEDICARE_THRESHOLD_SINGLE'); if ($amThr !== null) $this->additionalMedicareThresholdSingle = (float)$amThr;
        }
    }

    public function compute(array $payload): array
    {
        $schedule = $payload['pay_schedule'] ?? 'biweekly';
        $map = ['weekly'=>52,'biweekly'=>26,'semi-monthly'=>24,'monthly'=>12];
        $periodsYear = $map[$schedule] ?? 26;

        // Gross per period
        if (($payload['pay_type'] ?? 'hourly') === 'salary') {
            $grossPer = (float)$payload['annual_salary'] / max(1,$periodsYear);
        } else {
            $grossPer = (float)$payload['hourly_rate'] * (float)$payload['hours_per_period'];
        }

        $annualGross = $grossPer * $periodsYear;
        $taxableAnnual = max(0.0, $annualGross - $this->standardDeductionSingle);
        $federalAnnual = $this->estimateFederal($taxableAnnual);
        $federalPer = $federalAnnual / $periodsYear;

        // Social Security with wage base cap (assume within base for preview; simple cap check)
        $ssPer = min($grossPer * $this->ssRate, ($this->socialSecurityWageBase * $this->ssRate) / $periodsYear);
        // Medicare base
        $medPer = $grossPer * $this->medicareRate;
        // Additional Medicare (linear approximation distributing annual exceso entre periodos)
        $additionalMedAnnual = 0.0;
        if ($annualGross > $this->additionalMedicareThresholdSingle) {
            $excess = $annualGross - $this->additionalMedicareThresholdSingle;
            $additionalMedAnnual = $excess * $this->additionalMedicareRate;
        }
        $additionalMedPer = $additionalMedAnnual / $periodsYear;

        $stateCode = $payload['employee_state'] ?? null; // expects future field
        $statePer = 0.0;
        if ($stateCode && isset($this->stateFlat[$stateCode])) {
            $statePer = $grossPer * $this->stateFlat[$stateCode];
        }

        $earnings = [['label'=>'Regular Income','amount'=>round($grossPer,2)]];
        $taxes = [
            ['label'=>'Federal Tax (est.)','amount'=>round($federalPer,2)],
            ['label'=>'Social Security','amount'=>round($ssPer,2)],
            ['label'=>'Medicare','amount'=>round($medPer + $additionalMedPer,2)],
        ];
        if ($statePer > 0) { $taxes[] = ['label'=>'State Tax','amount'=>round($statePer,2)]; }

        $deductions = []; // future optional benefits

        return [
            'earnings' => $earnings,
            'taxes' => $taxes,
            'deductions' => $deductions,
            'gross_per_period' => round($grossPer,2),
            'federal_taxable_annual' => round($taxableAnnual,2),
            'net_per_period' => round($grossPer - array_sum(array_column($taxes,'amount')),2)
        ];
    }

    private function estimateFederal(float $taxableAnnual): float
    {
        $br = $this->federalBrackets2024Single;
        ksort($br);
        $tax = 0.0; $prevThreshold = 0; $prevRate = 0.0; $keys = array_keys($br);
        foreach ($keys as $idx=>$threshold) {
            $rate = $br[$threshold];
            if ($taxableAnnual <= $threshold) {
                $tax += ($taxableAnnual - $prevThreshold) * $prevRate;
                return $tax;
            }
            if ($idx>0) { // full bracket between prevThreshold and threshold
                $tax += ($threshold - $prevThreshold) * $prevRate;
            }
            $prevThreshold = $threshold;
            $prevRate = $rate;
        }
        // Above last threshold
        $tax += ($taxableAnnual - $prevThreshold) * $prevRate;
        return $tax;
    }
}
