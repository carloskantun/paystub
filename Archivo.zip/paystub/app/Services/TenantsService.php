<?php
namespace App\Services;

class TenantsService
{
    public function current(): array
    {
        // TODO: detect tenant based on host
        return [];
    }
}
