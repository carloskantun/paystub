<?php
namespace App\Services;

/**
 * CalculationOrchestrator
 * Usa TaxConfigRepository para obtener parámetros y genera líneas para N stubs.
 * Simplificación inicial (sin manual overrides todavía).
 */
class CalculationOrchestrator
{
    private TaxConfigRepository $repo;
    public function __construct()
    {
        $this->repo = service(TaxConfigRepository::class);
    }

    public function computeBatch(array $input): array
    {
        $year = (int)($input['year'] ?? date('Y'));
        $schedule = $input['pay_schedule'] ?? 'biweekly';
        $map = ['weekly'=>52,'biweekly'=>26,'semi-monthly'=>24,'monthly'=>12];
        $periodsYear = $map[$schedule] ?? 26;
        $stubs = (int)($input['stubs_count'] ?? 1);
        $payType = $input['pay_type'] ?? 'hourly';
        $hours = (float)($input['hours_per_period'] ?? 0);
        $rate = (float)($input['hourly_rate'] ?? 0);
        $annualSalary = (float)($input['annual_salary'] ?? 0);
        $state = $input['employee_state'] ?? null;
        $filing = 'single'; // placeholder futuro

        // Config
        $stdDed = $this->repo->getStandardDeduction($year, $filing);
        $brackets = $this->repo->getFederalBrackets($year, $filing);
        $fica = $this->repo->getFica($year);
        $stateRate = $this->repo->getStateRate($year, $state);

        // Gross per period
        if ($payType === 'salary') {
            $grossPer = $annualSalary / max(1,$periodsYear);
        } else {
            $grossPer = $rate * $hours;
        }
        $grossPer = max(0,$grossPer);
        $annualGross = $grossPer * $periodsYear;

        // Federal taxable annual
        $taxableAnnual = max(0.0, $annualGross - $stdDed);
        $federalAnnual = $this->federalTax($taxableAnnual, $brackets);
        $federalPer = $federalAnnual / $periodsYear;

        // FICA progressive across periods
        $ssRate = $fica['ss_rate_employee'];
        $ssBase = $fica['ss_wage_base'];
        $medRate = $fica['medicare_rate'];
        $addThr = $fica['addl_medicare_threshold_single'];
        $addRate = $fica['addl_medicare_rate'];

        $earningsLines = [];
        $taxLines = [];
        $summaries = [];
        $cumGross = 0.0; $cumTaxable = 0.0; $cumFed = 0.0; $cumSS = 0.0; $cumMed = 0.0; $cumState = 0.0;
        for ($i=0;$i<$stubs;$i++) {
            $cumGross += $grossPer;
            // Social Security: apply remaining base
            $remainingSS = max(0.0, $ssBase - ($cumGross - $grossPer));
            $ssCurrent = min($grossPer, $remainingSS) * $ssRate;
            if ($remainingSS <= 0) { $ssCurrent = 0.0; }
            $cumSS += $ssCurrent;

            // Medicare
            $medCurrent = $grossPer * $medRate;
            // Additional Medicare only on wages above threshold
            $prevGross = $cumGross - $grossPer;
            $segment = 0.0;
            if ($cumGross > $addThr) {
                $segment = min($grossPer, $cumGross - max($prevGross, $addThr));
            }
            $addMedCurrent = $segment * $addRate;
            $cumMed += $medCurrent + $addMedCurrent;

            // Federal (simple evenly distributed)
            $cumFed += $federalPer;

            // State
            $stateCurrent = $grossPer * $stateRate;
            $cumState += $stateCurrent;

            $earningsLines[$i] = [
                ['label'=>'Regular','hours'=>$payType==='hourly'? $hours : null,'rate'=>$payType==='hourly'? $rate : null,'current'=>$grossPer,'ytd'=>$grossPer*($i+1)]
            ];
            $taxLines[$i] = array_filter([
                ['label'=>'Federal Tax','current'=>$federalPer,'ytd'=>$federalPer*($i+1)],
                ['label'=>'Social Security','current'=>$ssCurrent,'ytd'=>$cumSS],
                ['label'=>'Medicare','current'=>$medCurrent + $addMedCurrent,'ytd'=>$cumMed],
                $stateRate>0 ? ['label'=>'State Tax','current'=>$stateCurrent,'ytd'=>$cumState] : null,
            ]);
            $taxTotalCurrent = array_sum(array_map(fn($t)=>$t['current'],$taxLines[$i]));
            $summaries[$i] = [
                'gross'=>$grossPer,
                'fit_taxable_wages'=>$taxableAnnual / $periodsYear,
                'taxes_total'=>$taxTotalCurrent,
                'deductions_total'=>0.0,
                'net'=>$grossPer - $taxTotalCurrent
            ];
        }

        return [
            'earnings'=>$earningsLines,
            'taxes'=>$taxLines,
            'deductions'=>array_fill(0,$stubs,[]),
            'summary'=>$summaries,
            'meta'=>[
                'gross_per_period'=>$grossPer,
                'annual_gross'=>$annualGross,
                'federal_taxable_annual'=>$taxableAnnual,
            ]
        ];
    }

    private function federalTax(float $taxableAnnual, array $brackets): float
    {
        $tax = 0.0; $prev=0.0; $prevRate = 0.0; $count = count($brackets);
        foreach ($brackets as $idx=>$b) {
            $thr = (float)$b['threshold']; $rate = (float)$b['rate'];
            if ($idx===0) { $prevRate = $rate; $prev = $thr; continue; }
            if ($taxableAnnual <= $thr) {
                $tax += ($taxableAnnual - $prev) * $prevRate; return $tax; }
            $tax += ($thr - $prev) * $prevRate; $prev = $thr; $prevRate = $rate;
        }
        // Above last threshold
        $tax += ($taxableAnnual - $prev) * $prevRate;
        return $tax;
    }
}
