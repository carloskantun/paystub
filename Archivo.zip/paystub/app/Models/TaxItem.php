<?php
namespace App\Models;

class TaxItem
{
    // TODO: define properties for tax items
}
