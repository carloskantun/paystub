<?php
namespace App\Models;

class DeductionItem
{
    // TODO: define properties for deduction items
}
