<?php
namespace App\Models;

class Tenant
{
    // TODO: define properties for tenants
}
