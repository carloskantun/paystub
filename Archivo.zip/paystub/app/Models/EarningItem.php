<?php
namespace App\Models;

class EarningItem
{
    // TODO: define properties for earning items
}
