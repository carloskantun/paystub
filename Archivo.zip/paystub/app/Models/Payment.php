<?php
namespace App\Models;

class Payment
{
    // TODO: define properties for payments
}
