<?php
namespace App\Models;

class Order
{
    // TODO: define properties and methods for Order model
}
