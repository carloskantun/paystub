<?php
return [
    'multi_tenant' => true,
];
