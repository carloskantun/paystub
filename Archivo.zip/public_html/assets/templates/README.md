# Template Images

Template PNG files should be placed here. They are omitted from the repository to avoid binary file issues.
